class person {
    public void speak() {
        System.out.println("Person speaks");
    }
}
class teacher extends person {
    public void speak() {
        System.out.println("Teacher speaks");
    }
}
public class Staticbinding {
    public static void main(String[] args) {
        person obj1;
        obj1 = new teacher();
        obj1.speak();
        person obj2 = new person();
        obj2.speak();
    }
}