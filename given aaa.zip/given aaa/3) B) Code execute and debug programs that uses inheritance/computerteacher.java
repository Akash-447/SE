class teeacher {
    String designation = "Teacher";
    String Collegename = "Polytechnic";
    void does() {
        System.out.println("Teaching");
    }}
public class computerteacher extends teeacher {
    String mainSubject = "Computer";
     public static void main(String[] args) {
        computerteacher obj = new computerteacher();
        System.out.println(obj.Collegename);
        System.out.println(obj.designation);
        System.out.println(obj.mainSubject);
        obj.does();
    }}

   
    
    

