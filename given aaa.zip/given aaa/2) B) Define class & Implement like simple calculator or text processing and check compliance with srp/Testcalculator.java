class Calculator{
    addition a = new addition();
    subtraction s =new subtraction();
    multiplication m =new multiplication();
    division d =new division();
    void performAddition(int x,int y){
        a.add(x,y);
    }
    void performSubtraction(int x,int y){
        s.sub(x,y);
    }
    void performMultiplication(int x, int y){
        m.mul(x,y);
    }
    void performDivision(int x,int y){
        d.div(x,y);
    }
}
class addition{
    int res;
    void add(int a,int b){
        res =a + b;
        System.out.println("Addition of two numbers = "+res);
    }
}
class subtraction{
    int res;
    void sub(int a,int b){
        res = a - b;
        System.out.println("Subtraction of two numbers = "+res);
    }
}
class multiplication{
    int res;
    void mul(int a, int b){
        res = a * b;
        System.out.println("multiplication of two numbers = "+res);
    }
}
class division{
    int res;
    void div(int a,int b){
        res = a / b;
        System.out.println("Division of two numbers = "+res);
    }
}
public class Testcalculator{
    public static void main(String[] args) {
        Calculator c = new Calculator();
        c.performAddition(1,2);
        c.performSubtraction(10,2);
        c.performMultiplication(10,5);
        c.performDivision(10,2);
    }
}
