interface bank1{
    float rateofIntrest();
}
class SBI implements bank1{
    public float rateofIntrest() {
        return 9.15f;
    }
}
class pnb implements bank1{
    public float rateofIntrest() {
        return 9.7f;
    }
}
public class run2 {
    public static void main(String[] args) {
        bank1 b = new SBI();
        System.out.println("ROI: " + b.rateofIntrest());
    }
}
