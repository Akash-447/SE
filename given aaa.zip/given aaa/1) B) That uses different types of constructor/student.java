public class student {
    public String name;
    public int age;
    public student() {
        this.name = "";
        this.age = 0;
    }
    public int getAge() {
        return age;
    }
    public String getName() {
        return name;
    }
    public static void main(String[] args) {
        student obj1 = new student();
        System.out.println("object 1:= " + obj1.getAge() + " name= " + obj1.getName());
    }
}