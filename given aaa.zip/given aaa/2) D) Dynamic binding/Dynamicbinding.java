class peerson {
    public void speak() {
        System.out.println("Person speaks");
    }
}
class person2 extends peerson {
    @Override
    public void speak() {
        System.out.println("Teacher speaks");
    }
}
public class Dynamicbinding {
    public static void main(String[] args) {
        peerson obj2 = new peerson();
        obj2.speak();
         peerson obj = new person2();
        obj.speak();
    }
}