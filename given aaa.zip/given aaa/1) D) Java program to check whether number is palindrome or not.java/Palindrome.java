public class Palindrome {
    public static void main(String[] args) {
        int r, sum = 0, temp;
        int n = 454; // Number to check for palindrome
        temp = n;
        while (n > 0) {
            r = n % 10; // Get the last digit
            sum = (sum * 10) + r; // Reverse the number
            n = n / 10; // Remove the last digit
        }
        if (temp == sum)
            System.out.println("Palindrome number");
        else
            System.out.println("Not a palindrome");
    }
}